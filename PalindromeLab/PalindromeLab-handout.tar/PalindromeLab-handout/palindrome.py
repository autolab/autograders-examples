"""
Params:
Integer: an integer, can be a positive or negative number

Return:
A boolean value (true if the integer is a palindrome number and false otherwise)
"""

def palindrome(integer):
    return True
