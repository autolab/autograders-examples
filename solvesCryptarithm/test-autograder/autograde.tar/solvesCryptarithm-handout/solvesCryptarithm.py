'''
solvesCryptarithm
Write your code for solvesCryptarithm in this file.
See README for problem statement.
'''

def solvesCryptarithm(puzzle, solution):
    return
