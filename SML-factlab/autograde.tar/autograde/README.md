# Autograding files
README                  README for this directory
autograde.mlb           ML Basis file containing the dependencies for the autograding executable
Autograder.sml          SML Autograder to test a student's submission
driver.sh               Script for compiling and running autograding executable
Tests.sml               SML file containing the autograded test cases