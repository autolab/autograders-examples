'''
File for storing custom test cases.

Each test case is formatted as an array of 4 elements:
0. Name of the test case
1. Array of integers
2. Target sum
3. Points rewarded
'''
test_cases = [
  ["Example case 1", [2,7,11,15], 9, 1]
]