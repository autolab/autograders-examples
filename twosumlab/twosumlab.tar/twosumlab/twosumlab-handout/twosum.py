'''
Parameters:
nums - An array of integers
target - An integer such that is the sum of a pair of integers from nums

Return: An integer array
See README for full instructions

'''
def two_sum(nums, target):
  return [0, 0]