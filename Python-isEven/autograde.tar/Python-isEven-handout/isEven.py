def isEven(x):
  return (x%2==0)
