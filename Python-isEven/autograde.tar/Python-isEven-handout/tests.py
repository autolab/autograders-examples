'''
Custom test cases can be written below.

Each test case is formatted as a list in the following order:
0. Name for test case
1. Valid Input (integer)
2. Points rewarded
'''

testCases = [
  ["Test 1", 72, 1],
  ["Test 2", -13, 1],
  ["Test 3", 0, 1],
]