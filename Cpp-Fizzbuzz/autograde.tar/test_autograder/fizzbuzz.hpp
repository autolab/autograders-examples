#include <string>

std::string fizzbuzz(int n);
