#pragma once

#include <vector>

std::vector<int> sort(std::vector<int> input);
