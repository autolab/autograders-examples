#include <vector>
#include "sort.hpp"
#include <iostream>

bool is_sorted(std::vector<int> input) {
    for (int i = 1; i < input.size(); ++i) {
        if (input.at(i - 1) > input.at(i)) {
            return false;
        }
    }
    return true;
}


int main() {
    std::vector<int> test1 = {5, 3, 4, 2, 1};
    std::vector<int> test2 = {};
    std::vector<int> test3 = {-1};
    std::vector<int> test4 = {-4, 5, 0};
    std::vector<std::vector<int>> all_tests = {test1, test2, test3, test4};
    int score = 0;
    for (auto test : all_tests) {
        auto sorted = sort(test);
        if (sorted.size() == test.size() && is_sorted(sorted)) {
            score++;
        }
    }
    std::cout << "{ \"scores\": { \"Prob1\": " << score << " } }" << std::endl;
    
}