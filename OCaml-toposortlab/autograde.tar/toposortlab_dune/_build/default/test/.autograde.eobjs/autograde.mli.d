test/autograde.mli:
