(* These graphs should all be directed acyclic graphs *)
open Core 
let graph1 : Toposort.graph  = {
  nodes = [1; 2; 3; 4; 5];
  edges = [(1, 2); (1, 3); (2, 4); (3, 4); (4, 5)];
}

let graph2 : Toposort.graph  = {
  nodes = [1; 2; 3; 4; 5; 6];
  edges = [(1, 2); (1, 3); (2, 4); (3, 4); (4, 5); (5, 6)];
}

let graph3 : Toposort.graph  = {
  nodes = [1; 2; 3; 4; 5; 6; 7];
  edges = [(1, 2); (1, 3); (2, 4); (3, 4); (4, 5); (5, 6); (6, 7)];
}

let graph4 : Toposort.graph  = {
  nodes = [1; 2; 3; 4; 5; 6; 7; 8];
  edges = [(1, 2); (1, 3); (2, 4); (3, 4); (4, 5); (5, 6); (6, 7); (7, 8)];
}

let graph5 : Toposort.graph  = {
  nodes = [1; 2; 3; 4; 5; 6; 7; 8; 9];
  edges = [(1, 2); (1, 3); (2, 4); (3, 4); (4, 5); (5, 6); (6, 7); (7, 8); (8, 9)];
}


let graphs = [graph1; graph2; graph3; graph4; graph5]

let check_toposort (g : Toposort.graph) : bool = 
  let sorted = Toposort.topological_sort g in
  let () = Printf.printf "Topological Sort: %s\n" (String.concat ~sep:", " (List.map ~f:Int.to_string sorted)) in
  (* First check that the sorted list is the same length as the nodes list *)
  if Set.length (Int.Set.of_list sorted) <> Set.length (Int.Set.of_list g.nodes) then
    false
  else
    (* Now iterate through the sorted list, keep a running tally of the nodes we've seen
     * and make sure that when we process a node, all of its predecessors have been seen *)
    
     (* Create the predecessor map *)
     let pred_map = Int.Map.of_alist_multi (List.map ~f:(fun (n, e) -> (e, n)) g.edges) in
     
     List.fold_until sorted ~init:Int.Set.empty ~f:(fun acc node ->
      let preds : int list = (match Int.Map.find pred_map node with
      | Some preds -> preds
      | None -> []) in
      if List.for_all preds ~f:(fun p -> Set.mem acc p) then
        Continue_or_stop.Continue (Set.add acc node)
      else
        Continue_or_stop.Stop (false)
      ) ~finish:(fun _ -> true)
  
(* Final output should be a JSON that looks like { "scores" : { "graph1" : 10, "graph2" : 10, "graph3" : 10, "graph4" : 10, "graph5" : 10 } } *)
let output_results () : unit = 
  let scores = List.mapi graphs ~f:(fun i g -> (Printf.sprintf "graph%d" (i + 1), if check_toposort g then 10 else 0)) in
  let scores_json = `Assoc (List.map ~f:(fun (name, score) -> (name, `Int score)) scores) in
  let output = `Assoc [("scores", scores_json)] in
  let output_json = Yojson.Basic.to_string output in
  printf "%s\n" output_json

let () = output_results ()
