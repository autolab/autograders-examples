type graph = { nodes : int list; edges : (int * int) list; }
val topological_sort : graph -> int list
