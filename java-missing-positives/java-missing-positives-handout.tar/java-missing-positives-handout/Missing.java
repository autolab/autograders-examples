/* 
 * Find smallest missing positive in an unsorted integer array
 */

public class Missing {
  public static int findSmallestMissingPositive(int[] L) {
    // write your code here
    return 0;
  }
}
