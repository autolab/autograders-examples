#include "sort.h"

/**
 * Sorts an integer array, in-place, in ascending order
 * 
 * @param[in,out] arr array of ints to be sorted
 * @param[in] n number of elements in arr
 */
void sort(int *arr, size_t n) {
    // TODO
}
